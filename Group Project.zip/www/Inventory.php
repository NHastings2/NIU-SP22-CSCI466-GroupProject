<html><head><title>Game Shop Inventory</title></head><body style="background-color:black; color:white;"><?php

include "Libraries/Inventory.php";

echo "<a style=\"color:#ADD8E6\" href=\".\">Back to home page</a>";

$inventory = GetInventoryItems();
$json = json_decode($inventory, true);

if (!empty($json)) {
    echo "<table border bordercolor=\"white\"><tr><th>Name</th><th>Quantity</th><th>Price</th><th>Item Page</th></tr>";
    foreach ($json as $key => $value) {
        echo "<tr><td>{$value["Product_Name"]}</td>
                <td>{$value["Product_in_Stock"]}</td>
                <td>\${$value["Product_Cost"]}</td>
                <td><a style=\"color:#ADD8E6\" href=\"Item.php?ID={$value["Product_ID"]}\">Item page</a></td></tr>";
    }
    echo "</table>";
} else {
    echo "The inventory is empty!";
}

?></body></html>