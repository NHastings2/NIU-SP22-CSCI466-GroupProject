<head>
    <title>Game Shop</title>
</head>
<body style="background-color:black; color:white;">
    <h1>Game Shop</h1>

    <h3>Inventory</h3>
    <a style="color:#ADD8E6" href="Inventory.php">View Inventory</a>

    <h3>Cart</h3>
    <a style="color:#ADD8E6" href="Cart.php">View Cart</a>

    <br>
    <br>
    <br>
    <br>
    <h2>Shop Management</h2>
    <h3>Orders</h3>
    <a style="color:#ADD8E6" href="Orders.php">View Orders</a>

    <h3>Customers</h3>
    <a style="color:#ADD8E6" href="Customers.php">View Customers</a>

</body>